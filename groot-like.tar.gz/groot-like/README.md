# [ GROOT ] Automated Linux Privilege Escalation Tool

Automated CVE-based privilege escalation toolkit for Linux.

## 🚀 Quick Start

```bash
# 1. Compile exploits
chmod +x build.sh
./build.sh

# 2. Run scanner
python3 groot.py

# 3. Run individual exploit
./exploits/exploit_pwnkit
```

## 📁 Files to Download

**Wajib download semua file ini:**

| File | Purpose | Size |
|------|---------|------|
| `groot.py` | Main scanner/orchestrator | ~8KB |
| `exploits/exploit_pwnkit.c` | CVE-2021-4034 source | ~1KB |
| `exploits/exploit_dirtypipe.c` | CVE-2022-0847 source | ~1KB |
| `exploits/exploit_dirtycow.c` | CVE-2016-5195 source | ~1KB |
| `build.sh` | Compile script | ~1KB |
| `README.md` | Documentation | ~3KB |

**Total: ~15KB (source only)**

Atau download archive jadi:
```bash
wget <url>/groot-like.tar.gz
tar -xzf groot-like.tar.gz
cd groot-like
./build.sh
```

## 📊 CVE Database

| CVE | Name | Kernel Range |
|-----|------|--------------|
| CVE-2021-4034 | PwnKit | All (pkexec) |
| CVE-2022-0847 | Dirty Pipe | 5.8 - 5.15.25 |
| CVE-2016-5195 | Dirty COW | 2.6.22 - 4.8.3 |

## ⚠️ Legal Warning

For authorized security testing only!
