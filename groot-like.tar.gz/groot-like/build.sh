#!/bin/bash
# GROOT-like Exploit Build Script

set -e
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}[GROOT] Building CVE Exploits...${NC}"
echo ""

cd "$(dirname "$0")/exploits"

for src in *.c; do
    if [ ! -f "$src" ]; then continue; fi
    
    bin="${src%.c}"
    echo -e "${BLUE}[*] Building ${bin}...${NC}"
    
    if gcc -static -O2 "$src" -o "$bin" 2>/dev/null; then
        echo -e "${GREEN}[+] ${bin} built (static)${NC}"
        chmod +x "$bin"
    elif gcc -O2 "$src" -o "$bin" 2>/dev/null; then
        echo -e "${YELLOW}[+] ${bin} built (dynamic)${NC}"
        chmod +x "$bin"
    else
        echo -e "${RED}[!] Failed to build ${bin}${NC}"
    fi
done

echo ""
echo -e "${GREEN}[+] Build complete!${NC}"
ls -la exploit_* 2>/dev/null | grep -v "\.c$" || true
